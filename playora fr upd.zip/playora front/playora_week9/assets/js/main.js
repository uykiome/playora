'use strict';

/* Playora frontend demo. The catalog data will move to PHP/MySQL in a later project week. */
const I18N = {
  kk: {
    navHome:'Басты бет', navCatalog:'Каталог', navCategories:'Жанрлар', navAbout:'Жоба туралы', navLogin:'Кіру', navRegister:'Тіркелу',
    loginWelcomeEyebrow:'ҚАЙТА КЕЛГЕНІҢЕ ҚУАНЫШТЫМЫЗ', loginHeroTitle:'Ойын әлемі<br><span>сені күтеді.</span>', loginHeroText:'Аккаунтыңа кіріп, өзіңе ұнайтын ойындарды бір жерге жина.', loginCardEyebrow:'PLAYORA АККАУНТЫ', loginTitle:'Жүйеге кіру', loginCardText:'Жалғастыру үшін деректеріңді енгіз.', loginEmailLabel:'Электрондық пошта', loginPasswordLabel:'Құпиясөз', loginPasswordPlaceholder:'Құпиясөзіңді енгіз', loginSubmit:'Кіру <span>→</span>', loginNoAccount:'Аккаунтың жоқ па?', loginPrototype:'Бұл — frontend үлгісі. Нақты авторизация PHP және MySQL қосылғанда іске қосылады.',
    registerWelcomeEyebrow:'ӨЗ ОЙЫН ӘЛЕМІҢДІ БАСТА', registerHeroTitle:'Жаңа деңгейге<br><span>көтеріл.</span>', registerHeroText:'Тіркеліп, өзіңе ұнайтын ойындарды таңдаулылар тізіміне жина.', registerCardEyebrow:'ҚАУЫМДАСТЫҚҚА ҚОСЫЛ', registerTitle:'Тіркелу', registerCardText:'Жаңа аккаунт жасау үшін форманы толтыр.', registerNameLabel:'Пайдаланушы аты', registerNamePlaceholder:'Мысалы, player01', registerEmailLabel:'Электрондық пошта', registerPasswordLabel:'Құпиясөз', registerPasswordPlaceholder:'Кемінде 8 таңба', registerConfirmLabel:'Құпиясөзді қайтала', registerConfirmPlaceholder:'Құпиясөзді қайта енгіз', registerSubmit:'Аккаунт жасау <span>→</span>', registerHasAccount:'Аккаунтың бар ма?', registerPrototype:'Бұл — frontend үлгісі. Деректер әзірше серверге сақталмайды.',
    heroEyebrow:'ТАҢДАЛҒАН ОЙЫНДАР', discoverEyebrow:'ІЗДЕУ ЖӘНЕ ТАБУ', discoverTitle:'Қандай ойын іздеп жүрсің?', discoverDescription:'Атын жаз немесе жанрды таңда — нәтижелер бірден жаңарады.', searchPlaceholder:'Ойын атауын енгізіңіз', quickFilters:'ЖЫЛДАМ СҮЗГІЛЕР',
    filterAll:'Барлық ойын', filterAction:'Экшн (Action)', filterCombat:'Боевик', filterHorror:'Мистика / Хоррор', filterAdventure:'Приключения', filterRpg:'Рөлдік ойындар (RPG)', filterMultiplayer:'Мультиплеер',
    popularEyebrow:'ҚАЗІР ТАНЫМАЛ', popularTitle:'Қазір <span>танымал</span>', seeCatalog:'Каталогқа өту <span>↗</span>', categoryEyebrow:'КӨҢІЛ-КҮЙІҢЕ ҚАРАЙ', categoryTitle:'Жанрды <span>таңда</span>', categoryDescription:'Санатты таңдасаң, каталог сол жанрға бірден сүзгіленеді.',
    tileExplore:'Қарқын мен әрекет', tileCombat:'Шайқас пен стратегия', tileHorror:'Құпия және қорқыныш', tileAdventure:'Жаңа әлемдерді зертте', tileRpg:'Оқиғаңды өзің жаз', tileMultiplayer:'Достармен бірге',
    topWeekEyebrow:'ОЙЫНШЫЛАР ТАҢДАУЫ', topWeekTitle:'Аптаның <span>топ ойындары</span>', freeEyebrow:'ҚОСЫМША ШЫҒЫНСЫЗ', freeTitle:'Тегін <span>ойындар</span>', paidEyebrow:'ЖАҢА ӘЛЕМГЕ ҚАДАМ', paidTitle:'Ақылы <span>ойындар</span>', sampleDataNote:'Рейтингтер мен бағалар — демо деректер', samplePricesNote:'Бағалар мысал ретінде көрсетілген',
    catalogEyebrow:'ТОЛЫҚ КІТАПХАНА', catalogTitle:'Ойындар <span>каталогы</span>', sortLabel:'Сұрыптау:', sortRating:'Рейтинг бойынша', sortNewest:'Жаңа → ескі', sortOldest:'Ескі → жаңа', sortAZ:'Атауы A–Z', sortPrice:'Бағасы бойынша',
    emptyTitle:'Ойын табылмады', emptyText:'Іздеу сөзін немесе жанр сүзгісін өзгертіп көр.', resetFilters:'Сүзгіні тазарту', catalogBottomNote:'Жаңа ойындар каталогқа біртіндеп қосылады.', backToTop:'Жоғарыға ↑', aboutEyebrow:'PLAYORA ТУРАЛЫ', aboutTitle:'Ойын әлемі —<br><span>бір жерде.</span>', aboutText:'Playora — компьютерлік ойындар туралы ақпаратты қарауға, ойындарды іздеуге және ұнағандарын таңдаулыларға сақтауға арналған оқу жобасы.', aboutCta:'Өз аккаунтыңды жаса', footerNote:'Оқу жобасы.',
    heroDetails:'Ойынды көру', heroSave:'Таңдаулыларға', heroSaved:'Таңдаулыларда', heroKicker:'PLAYORA ТАҢДАУЫ', heroDescriptionFallback:'Жаңа әлемдерді ашып, өзіңе ұнайтын ойынды тап.', popularTag:'ТАНЫМАЛ', ratingLabel:'рейтинг',
    freePrice:'Тегін', detailPriceDemo:'Бағасы — демо', backToCatalog:'Каталогқа оралу', featuredArt:'ОЙЫННЫҢ НЕГІЗГІ АРТЫ', gameProfile:'ОЙЫН ПРОФИЛІ', priceLabel:'Бағасы', demoPriceNote:'Демо баға', viewGallery:'Галереяны көру', detailPrototypeNote:'Бұл — frontend үлгісі. Деректер кейін MySQL дерекқорынан жүктеледі.', gameInfoEyebrow:'ҚЫСҚАША МӘЛІМЕТ', gameInfoTitle:'Ойын <span>ақпараты</span>', languageEyebrow:'ҚОЛЖЕТІМДІ ТІЛДЕР', languageTitle:'Ойын <span>тілдері</span>', languageHelp:'Бұл — интерфейс тілінен бөлек, ойынның өзінде қолжетімді тілдер тізімі. Қазір бұл демонстрациялық дерек — нақты тілдерді базаға енгізер алдында әр ойын бойынша тексеру керек.', galleryEyebrow:'ОЙЫН ІШІНЕН', galleryTitle:'Скриншоттар мен <span>арттар</span>', galleryNote:'Суреттер интернет арқылы жүктеледі', factGenre:'Жанры', factYear:'Шыққан жылы', factMode:'Ойын режимі', factPlatforms:'Платформалар', factPublisher:'Баспагер', factLanguageCount:'Қолжетімді тілдер', galleryImage:'Көрініс',
    genreAction:'Экшн', genreCombat:'Боевик / Шутер', genreHorror:'Мистика / Хоррор', genreAdventure:'Приключения', genreRpg:'Рөлдік ойын (RPG)', genreMultiplayer:'Мультиплеер', genreSandbox:'Sandbox', genreSimulation:'Симулятор', genreStrategy:'Стратегия', modeSingle:'Бір ойыншы', modeOnline:'Онлайн мультиплеер', modeMixed:'Бір ойыншы / онлайн', platformPC:'PC', platformConsole:'Консольдер',
    toastAdded:'таңдаулыларға қосылды.', toastRemoved:'таңдаулылардан алынды.', toastStorage:'Браузерде сақтауға рұқсат жоқ.', countGames:'ойын көрсетілді',
    loginShow:'Көрсету', loginHide:'Жасыру', loginValid:'Форма дұрыс толтырылды. Нақты кіру жүйесі PHP және MySQL қосылғанда жұмыс істейді.', registerMismatch:'Екі құпиясөздің бірдей екенін тексер.', registerValid:'Форма дұрыс толтырылды. Аккаунтты дерекқорға сақтау 11-аптада қосылады.',
    genres:{action:'Экшн',combat:'Боевик / Шутер',horror:'Мистика / Хоррор',adventure:'Приключения',rpg:'RPG',multiplayer:'Мультиплеер',sandbox:'Sandbox',simulation:'Симулятор',strategy:'Стратегия'},
    factKeys:{genre:'Жанры',year:'Шыққан жылы',mode:'Ойын режимі',platforms:'Платформалар',publisher:'Баспагер'},
    langs:{en:'Ағылшын',it:'Итальян',zhHant:'Қытай (дәстүрлі)',zhHans:'Қытай (жеңілдетілген)',ko:'Корей',de:'Неміс',ptBR:'Португал (Бразилия)',ru:'Орыс',fr:'Француз (Франция)',ja:'Жапон',esMX:'Испан (Мексика)'}
  },
  ru: {
    navHome:'Главная', navCatalog:'Каталог', navCategories:'Жанры', navAbout:'О проекте', navLogin:'Войти', navRegister:'Регистрация',
    loginWelcomeEyebrow:'РАДЫ СНОВА ТЕБЯ ВИДЕТЬ', loginHeroTitle:'Игровой мир<br><span>ждёт тебя.</span>', loginHeroText:'Войди в аккаунт и собирай понравившиеся игры в одном месте.', loginCardEyebrow:'АККАУНТ PLAYORA', loginTitle:'Вход', loginCardText:'Введи данные, чтобы продолжить.', loginEmailLabel:'Электронная почта', loginPasswordLabel:'Пароль', loginPasswordPlaceholder:'Введи пароль', loginSubmit:'Войти <span>→</span>', loginNoAccount:'Нет аккаунта?', loginPrototype:'Это frontend-прототип. Настоящая авторизация появится после подключения PHP и MySQL.',
    registerWelcomeEyebrow:'НАЧНИ СВОЁ ИГРОВОЕ ПРИКЛЮЧЕНИЕ', registerHeroTitle:'Новый уровень<br><span>начинается здесь.</span>', registerHeroText:'Зарегистрируйся и собирай понравившиеся игры в избранное.', registerCardEyebrow:'ПРИСОЕДИНЯЙСЯ К PLAYORA', registerTitle:'Регистрация', registerCardText:'Заполни форму, чтобы создать аккаунт.', registerNameLabel:'Имя пользователя', registerNamePlaceholder:'Например, player01', registerEmailLabel:'Электронная почта', registerPasswordLabel:'Пароль', registerPasswordPlaceholder:'Не менее 8 символов', registerConfirmLabel:'Повтори пароль', registerConfirmPlaceholder:'Введи пароль ещё раз', registerSubmit:'Создать аккаунт <span>→</span>', registerHasAccount:'Уже есть аккаунт?', registerPrototype:'Это frontend-прототип. Данные пока не сохраняются на сервере.',
    heroEyebrow:'ВЫБОР PLAYORA', discoverEyebrow:'ПОИСК И ОТКРЫТИЯ', discoverTitle:'Какую игру ищешь?', discoverDescription:'Введи название или выбери жанр — список обновится сразу.', searchPlaceholder:'Enter game name', quickFilters:'БЫСТРЫЕ ФИЛЬТРЫ',
    filterAll:'Все игры', filterAction:'Экшн (Action)', filterCombat:'Боевик', filterHorror:'Мистика / Хоррор', filterAdventure:'Приключения', filterRpg:'Ролевые (RPG)', filterMultiplayer:'Мультиплеер',
    popularEyebrow:'СЕЙЧАС ПОПУЛЯРНО', popularTitle:'Популярное <span>сейчас</span>', seeCatalog:'Весь каталог <span>↗</span>', categoryEyebrow:'ВЫБИРАЙ ПО НАСТРОЕНИЮ', categoryTitle:'Выбери <span>жанр</span>', categoryDescription:'Нажми на категорию — каталог мгновенно отфильтруется по выбранному жанру.',
    tileExplore:'Драйв и действие', tileCombat:'Битвы и стратегия', tileHorror:'Тайны и страх', tileAdventure:'Исследуй новые миры', tileRpg:'Создай свою историю', tileMultiplayer:'Играй с друзьями',
    topWeekEyebrow:'ВЫБОР ИГРОКОВ', topWeekTitle:'Топ игр <span>недели</span>', freeEyebrow:'БЕЗ ДОПОЛНИТЕЛЬНЫХ ТРАТ', freeTitle:'Бесплатные <span>игры</span>', paidEyebrow:'НОВЫЕ МИРЫ ЖДУТ', paidTitle:'Платные <span>игры</span>', sampleDataNote:'Рейтинги и цены — демо-данные', samplePricesNote:'Цены приведены для примера',
    catalogEyebrow:'ВСЯ БИБЛИОТЕКА', catalogTitle:'Каталог <span>игр</span>', sortLabel:'Сортировка:', sortRating:'По рейтингу', sortNewest:'Сначала новые', sortOldest:'Сначала старые', sortAZ:'Название A–Z', sortPrice:'По цене',
    emptyTitle:'Игры не найдены', emptyText:'Попробуй изменить запрос или выбранный жанр.', resetFilters:'Сбросить фильтр', catalogBottomNote:'Новые игры будут постепенно добавляться в каталог.', backToTop:'Наверх ↑', aboutEyebrow:'О PLAYORA', aboutTitle:'Игровой мир —<br><span>в одном месте.</span>', aboutText:'Playora — учебный проект-каталог, где можно изучать информацию о компьютерных играх, искать их и сохранять понравившиеся в избранное.', aboutCta:'Создать аккаунт', footerNote:'Учебный проект.',
    heroDetails:'Подробнее об игре', heroSave:'В избранное', heroSaved:'В избранном', heroKicker:'ВЫБОР PLAYORA', heroDescriptionFallback:'Открывай новые миры и находи игру по душе.', popularTag:'ПОПУЛЯРНОЕ', ratingLabel:'рейтинг',
    freePrice:'Бесплатно', detailPriceDemo:'Цена — демо', backToCatalog:'Вернуться в каталог', featuredArt:'ГЛАВНЫЙ АРТ ИГРЫ', gameProfile:'ПРОФИЛЬ ИГРЫ', priceLabel:'Цена', demoPriceNote:'Демо-цена', viewGallery:'Смотреть галерею', detailPrototypeNote:'Это frontend-прототип. Позже данные будут загружаться из MySQL.', gameInfoEyebrow:'КРАТКАЯ ИНФОРМАЦИЯ', gameInfoTitle:'Информация <span>об игре</span>', languageEyebrow:'ДОСТУПНЫЕ ЯЗЫКИ', languageTitle:'Языки <span>игры</span>', languageHelp:'Это языки, доступные внутри игры, а не язык интерфейса сайта. Пока список демонстрационный: перед заполнением базы нужно проверить языки отдельно для каждой игры.', galleryEyebrow:'В ИГРЕ', galleryTitle:'Скриншоты и <span>арты</span>', galleryNote:'Изображения загружаются из интернета', factGenre:'Жанр', factYear:'Год выхода', factMode:'Режим игры', factPlatforms:'Платформы', factPublisher:'Издатель', factLanguageCount:'Доступные языки', galleryImage:'Кадр',
    genreAction:'Экшн', genreCombat:'Боевик / Шутер', genreHorror:'Мистика / Хоррор', genreAdventure:'Приключения', genreRpg:'Ролевая игра (RPG)', genreMultiplayer:'Мультиплеер', genreSandbox:'Песочница', genreSimulation:'Симулятор', genreStrategy:'Стратегия', modeSingle:'Одиночная игра', modeOnline:'Онлайн-мультиплеер', modeMixed:'Одиночная игра / онлайн', platformPC:'PC', platformConsole:'Консоли',
    toastAdded:'добавлена в избранное.', toastRemoved:'удалена из избранного.', toastStorage:'Браузер не разрешает сохранять данные.', countGames:'игр показано',
    loginShow:'Показать', loginHide:'Скрыть', loginValid:'Форма заполнена корректно. Реальный вход заработает после подключения PHP и MySQL.', registerMismatch:'Проверь, что оба пароля совпадают.', registerValid:'Форма заполнена корректно. Сохранение аккаунта в базу данных добавим на 11-й неделе.',
    genres:{action:'Экшн',combat:'Боевик / Шутер',horror:'Мистика / Хоррор',adventure:'Приключения',rpg:'RPG',multiplayer:'Мультиплеер',sandbox:'Песочница',simulation:'Симулятор',strategy:'Стратегия'},
    factKeys:{genre:'Жанр',year:'Год выхода',mode:'Режим игры',platforms:'Платформы',publisher:'Издатель'},
    langs:{en:'Английский',it:'Итальянский',zhHant:'Китайский (традиционный)',zhHans:'Китайский (упрощённый)',ko:'Корейский',de:'Немецкий',ptBR:'Португальский (Бразилия)',ru:'Русский',fr:'Французский (Франция)',ja:'Японский',esMX:'Испанский (Мексика)'}
  },
  en: {
    navHome:'Home', navCatalog:'Catalog', navCategories:'Genres', navAbout:'About', navLogin:'Log in', navRegister:'Sign up',
    loginWelcomeEyebrow:'WELCOME BACK', loginHeroTitle:'Your gaming world<br><span>is waiting.</span>', loginHeroText:'Sign in and keep your favorite games in one place.', loginCardEyebrow:'PLAYORA ACCOUNT', loginTitle:'Log in', loginCardText:'Enter your details to continue.', loginEmailLabel:'Email address', loginPasswordLabel:'Password', loginPasswordPlaceholder:'Enter your password', loginSubmit:'Log in <span>→</span>', loginNoAccount:'Don’t have an account?', loginPrototype:'This is a frontend prototype. Real authentication will be enabled when PHP and MySQL are connected.',
    registerWelcomeEyebrow:'START YOUR GAMING JOURNEY', registerHeroTitle:'Your next level<br><span>starts here.</span>', registerHeroText:'Create an account and save the games you like to favorites.', registerCardEyebrow:'JOIN THE COMMUNITY', registerTitle:'Sign up', registerCardText:'Fill in the form to create an account.', registerNameLabel:'Username', registerNamePlaceholder:'e.g. player01', registerEmailLabel:'Email address', registerPasswordLabel:'Password', registerPasswordPlaceholder:'At least 8 characters', registerConfirmLabel:'Confirm password', registerConfirmPlaceholder:'Enter your password again', registerSubmit:'Create account <span>→</span>', registerHasAccount:'Already have an account?', registerPrototype:'This is a frontend prototype. Data is not saved to a server yet.',
    heroEyebrow:'PLAYORA SPOTLIGHT', discoverEyebrow:'SEARCH & DISCOVER', discoverTitle:'What do you want to play?', discoverDescription:'Type a title or choose a genre — results update instantly.', searchPlaceholder:'Enter game name', quickFilters:'QUICK FILTERS',
    filterAll:'All games', filterAction:'Action', filterCombat:'Shooter / Combat', filterHorror:'Mystery / Horror', filterAdventure:'Adventure', filterRpg:'Role-playing (RPG)', filterMultiplayer:'Multiplayer',
    popularEyebrow:'TRENDING NOW', popularTitle:'Trending <span>now</span>', seeCatalog:'Browse catalog <span>↗</span>', categoryEyebrow:'PICK YOUR MOOD', categoryTitle:'Choose a <span>genre</span>', categoryDescription:'Choose a category to instantly filter the catalog by genre.',
    tileExplore:'Action and adrenaline', tileCombat:'Combat and strategy', tileHorror:'Mystery and suspense', tileAdventure:'Explore new worlds', tileRpg:'Write your own story', tileMultiplayer:'Play with friends',
    topWeekEyebrow:'PLAYER PICKS', topWeekTitle:'Top games of the <span>week</span>', freeEyebrow:'PLAY WITHOUT EXTRA COST', freeTitle:'Free-to-play <span>games</span>', paidEyebrow:'YOUR NEXT ADVENTURE', paidTitle:'Premium <span>games</span>', sampleDataNote:'Ratings and prices are demo data', samplePricesNote:'Prices are examples only',
    catalogEyebrow:'THE FULL LIBRARY', catalogTitle:'Game <span>catalog</span>', sortLabel:'Sort:', sortRating:'Top rated', sortNewest:'Newest first', sortOldest:'Oldest first', sortAZ:'Title A–Z', sortPrice:'Price',
    emptyTitle:'No games found', emptyText:'Try changing your search or genre filter.', resetFilters:'Clear filters', catalogBottomNote:'More games will be added to the catalog over time.', backToTop:'Back to top ↑', aboutEyebrow:'ABOUT PLAYORA', aboutTitle:'Your gaming world —<br><span>in one place.</span>', aboutText:'Playora is a learning project for browsing computer game information, searching titles and saving favorites.', aboutCta:'Create an account', footerNote:'Student project.',
    heroDetails:'View game', heroSave:'Add to favorites', heroSaved:'In favorites', heroKicker:'PLAYORA PICK', heroDescriptionFallback:'Explore new worlds and find your next favorite game.', popularTag:'TRENDING', ratingLabel:'rating',
    freePrice:'Free to play', detailPriceDemo:'Price — demo', backToCatalog:'Back to catalog', featuredArt:'FEATURED GAME ART', gameProfile:'GAME PROFILE', priceLabel:'Price', demoPriceNote:'Demo price', viewGallery:'View gallery', detailPrototypeNote:'This is a frontend prototype. Data will be loaded from MySQL later.', gameInfoEyebrow:'AT A GLANCE', gameInfoTitle:'Game <span>details</span>', languageEyebrow:'AVAILABLE LANGUAGES', languageTitle:'Game <span>languages</span>', languageHelp:'These are in-game languages, separate from the site interface language. This list is demo data and should be verified for each title before the database is filled.', galleryEyebrow:'IN-GAME VISUALS', galleryTitle:'Screenshots & <span>artwork</span>', galleryNote:'Images load from the internet', factGenre:'Genre', factYear:'Release year', factMode:'Game mode', factPlatforms:'Platforms', factPublisher:'Publisher', factLanguageCount:'Available languages', galleryImage:'View',
    genreAction:'Action', genreCombat:'Shooter / Combat', genreHorror:'Mystery / Horror', genreAdventure:'Adventure', genreRpg:'Role-playing (RPG)', genreMultiplayer:'Multiplayer', genreSandbox:'Sandbox', genreSimulation:'Simulation', genreStrategy:'Strategy', modeSingle:'Single-player', modeOnline:'Online multiplayer', modeMixed:'Single-player / online', platformPC:'PC', platformConsole:'Consoles',
    toastAdded:'added to favorites.', toastRemoved:'removed from favorites.', toastStorage:'Browser storage is unavailable.', countGames:'games shown',
    loginShow:'Show', loginHide:'Hide', loginValid:'The form is valid. Real login will work after PHP and MySQL are connected.', registerMismatch:'Check that both passwords match.', registerValid:'The form is valid. Saving accounts to the database will be added in week 11.',
    genres:{action:'Action',combat:'Shooter / Combat',horror:'Mystery / Horror',adventure:'Adventure',rpg:'RPG',multiplayer:'Multiplayer',sandbox:'Sandbox',simulation:'Simulation',strategy:'Strategy'},
    factKeys:{genre:'Genre',year:'Release year',mode:'Game mode',platforms:'Platforms',publisher:'Publisher'},
    langs:{en:'English',it:'Italian',zhHant:'Chinese (Traditional)',zhHans:'Chinese (Simplified)',ko:'Korean',de:'German',ptBR:'Portuguese (Brazil)',ru:'Russian',fr:'French (France)',ja:'Japanese',esMX:'Spanish (Mexico)'}
  }
};

const GAME_DATA = [
  {id:'genshin-impact',title:'Genshin Impact',year:2020,genres:['rpg','action','adventure','multiplayer'],publisher:'HoYoverse',platforms:['PC','PlayStation','Mobile'],mode:'mixed',rating:4.7,votes:'18.2k',price:0,theme:'genshin',code:'GI',steamId:null,description:{kk:'Тиватты зерттеп, ерекше кейіпкерлермен бірге Тейват әлемінің құпияларын аш.',ru:'Исследуй Тейват, собирай команду героев и открывай тайны огромного фэнтези-мира.',en:'Explore Teyvat, build a team of heroes and uncover the secrets of a vast fantasy world.'},languages:['en','it','zhHant','zhHans','ko','de','ptBR','ru','fr','ja','esMX']},
  {id:'minecraft',title:'Minecraft',year:2011,genres:['adventure','multiplayer','sandbox'],publisher:'Mojang Studios',platforms:['PC','Console','Mobile'],mode:'mixed',rating:4.8,votes:'25.1k',price:9990,theme:'minecraft',code:'MC',steamId:null,description:{kk:'Блоктардан өз әлеміңді құрып, үңгірлерді зертте және достарыңмен бірге ойна.',ru:'Создавай миры из блоков, исследуй пещеры и играй вместе с друзьями.',en:'Build worlds block by block, explore caves and create adventures with friends.'},languages:['en','zhHant','zhHans','ko','de','ptBR','ru','fr','ja','esMX']},
  {id:'roblox',title:'Roblox',year:2006,genres:['adventure','multiplayer','simulation'],publisher:'Roblox Corporation',platforms:['PC','Console','Mobile'],mode:'online',rating:4.6,votes:'31.7k',price:0,theme:'roblox',code:'R',steamId:null,description:{kk:'Мыңдаған ойын мен әлемді аш, өз тәжірибеңді жаса және достарыңмен ойна.',ru:'Открывай тысячи пользовательских миров, создавай собственные впечатления и играй с друзьями.',en:'Discover thousands of user-created worlds, build experiences and play with friends.'},languages:['en','it','zhHant','zhHans','ko','de','ptBR','ru','fr','ja','esMX']},
  {id:'final-fantasy-xiv',title:'Final Fantasy XIV',year:2013,genres:['rpg','adventure','multiplayer'],publisher:'Square Enix',platforms:['PC','PlayStation'],mode:'online',rating:4.8,votes:'9.6k',price:0,theme:'ffxiv',code:'FFXIV',steamId:39210,description:{kk:'Кең фэнтези әлемінде тапсырмалар орындап, кейіпкеріңді дамыт және басқа ойыншылармен сапарға шық.',ru:'Выполняй задания, развивай персонажа и отправляйся в приключения с игроками со всего мира.',en:'Complete quests, develop your character and adventure with players from around the world.'},languages:['en','de','fr','ja']},
  {id:'cyberpunk-2077',title:'Cyberpunk 2077',year:2020,genres:['action','rpg','adventure'],publisher:'CD PROJEKT RED',platforms:['PC','PlayStation','Xbox'],mode:'single',rating:4.8,votes:'14.3k',price:16990,theme:'cyber',code:'2077',steamId:1091500,description:{kk:'Түнгі қалада өз жолыңды таңда. Технология, билік және адам тағдыры тоғысқан болашақты зертте.',ru:'Выбирай собственный путь в Найт-Сити — мегаполисе, где технологии, власть и человеческие судьбы переплетены.',en:'Choose your path in Night City, a metropolis shaped by technology, power and human ambition.'},languages:['en','it','zhHans','ko','de','ptBR','ru','fr','ja','esMX']},
  {id:'elden-ring',title:'Elden Ring',year:2022,genres:['action','rpg','adventure'],publisher:'Bandai Namco Entertainment',platforms:['PC','PlayStation','Xbox'],mode:'mixed',rating:4.9,votes:'16.8k',price:19990,theme:'elden',code:'ER',steamId:1245620,description:{kk:'Құпияға толы кең әлемді зерттеп, қиын шайқастардан өтіп, Аралық жерлердің сырын аш.',ru:'Исследуй загадочные земли, преодолевай непростые испытания и раскрывай тайны Междуземья.',en:'Explore mysterious lands, overcome challenging battles and uncover the secrets of the Lands Between.'},languages:['en','it','zhHans','ko','de','ptBR','ru','fr','ja','esMX']},
  {id:'valorant',title:'VALORANT',year:2020,genres:['action','combat','multiplayer'],publisher:'Riot Games',platforms:['PC'],mode:'online',rating:4.5,votes:'12.2k',price:0,theme:'valorant',code:'V.',steamId:null,description:{kk:'Командаңмен бірге тактика құрып, ерекше қабілеттерді пайдалан және раунд сайын жеңіске ұмтыл.',ru:'Продумывай тактику с командой, используй уникальные способности и борись за победу в каждом раунде.',en:'Coordinate with your team, use unique abilities and fight for every round.'},languages:['en','zhHant','zhHans','ko','de','ru','fr','ja','esMX']},
  {id:'grand-theft-auto-v',title:'Grand Theft Auto V',year:2013,genres:['action','combat','adventure','multiplayer'],publisher:'Rockstar Games',platforms:['PC','PlayStation','Xbox'],mode:'mixed',rating:4.7,votes:'20.4k',price:12990,theme:'gta',code:'V',steamId:271590,description:{kk:'Лос-Сантос қаласындағы оқиғаларға араласып, ашық әлемде өз бағытыңды таңда.',ru:'Погрузись в истории Лос-Сантоса и выбирай собственный путь в большом открытом мире.',en:'Dive into the stories of Los Santos and choose your path in a vast open world.'},languages:['en','it','zhHans','de','ptBR','ru','fr','ja','esMX']},
  {id:'the-witcher-3',title:'The Witcher 3: Wild Hunt',year:2015,genres:['rpg','adventure','action'],publisher:'CD PROJEKT RED',platforms:['PC','PlayStation','Xbox','Nintendo Switch'],mode:'single',rating:4.9,votes:'15.7k',price:4990,theme:'witcher',code:'W3',steamId:292030,description:{kk:'Жалдамалы аңшы Геральтпен бірге құбыжықтар, күрделі шешімдер және есте қаларлық оқиғаларға толы әлемді арала.',ru:'Отправляйся в путь с ведьмаком Геральтом: чудовища, непростые решения и истории ждут на каждом шагу.',en:'Travel with Geralt through a world of monsters, difficult choices and memorable stories.'},languages:['en','it','zhHans','ko','de','ptBR','ru','fr','ja','esMX']},
  {id:'phasmophobia',title:'Phasmophobia',year:2020,genres:['horror','multiplayer'],publisher:'Kinetic Games',platforms:['PC'],mode:'online',rating:4.6,votes:'7.4k',price:6990,theme:'phasmo',code:'PH',steamId:739630,description:{kk:'Достарыңмен бірге паранормалды құбылыстарды зерттеп, қорқынышты орындардан дәлел жина.',ru:'Вместе с командой исследуй паранормальные явления и собирай доказательства в жутких местах.',en:'Investigate paranormal activity with your team and collect evidence in unsettling locations.'},languages:['en','it','zhHans','ko','de','ru','fr','ja','esMX']},
  {id:'dota-2',title:'Dota 2',year:2013,genres:['combat','multiplayer','strategy'],publisher:'Valve',platforms:['PC'],mode:'online',rating:4.6,votes:'11.8k',price:0,theme:'dota',code:'D2',steamId:570,description:{kk:'Командаңмен стратегия құрып, әртүрлі қабілеттері бар кейіпкерлер арқылы жеңіске жет.',ru:'Строй командную стратегию и используй способности героев, чтобы привести свою команду к победе.',en:'Build team strategies and use a roster of heroes to outplay the opposing team.'},languages:['en','it','zhHant','zhHans','ko','de','ptBR','ru','fr','ja','esMX']},
  {id:'apex-legends',title:'Apex Legends',year:2019,genres:['action','combat','multiplayer'],publisher:'Electronic Arts',platforms:['PC','PlayStation','Xbox'],mode:'online',rating:4.5,votes:'8.9k',price:0,theme:'apex',code:'APEX',steamId:1172470,description:{kk:'Бірегей қабілеттері бар қаһармандармен команда құр және қарқынды шайқастарда аман қал.',ru:'Собирай отряд героев с уникальными умениями и сражайся в динамичных матчах.',en:'Build a squad of legends with unique abilities and compete in fast-paced battles.'},languages:['en','it','zhHans','ko','de','ptBR','ru','fr','ja','esMX']}
];

const HERO_SLIDES = [
  {gameId:'cyberpunk-2077',kicker:{kk:'ТҮНГІ ҚАЛАНЫ ЗЕРТТЕ',ru:'ИССЛЕДУЙ НОЧНОЙ ГОРОД',en:'EXPLORE NIGHT CITY'},title:{kk:'Өз аңызыңды жаз.',ru:'Напиши свою легенду.',en:'Write your own legend.'},description:{kk:'Неон жарықтары, батыл шешімдер және болашақ мегаполисі сені күтеді.',ru:'Неоновые улицы, смелые решения и огромный футуристический город ждут тебя.',en:'Neon streets, bold choices and a sprawling futuristic city await.'}},
  {gameId:'elden-ring',kicker:{kk:'ҚҰПИЯЛАРҒА ТОЛЫ ӘЛЕМ',ru:'МИР ПОЛОН ТАЙН',en:'A WORLD FULL OF MYSTERY'},title:{kk:'Белгісізге қадам бас.',ru:'Шагни в неизвестность.',en:'Step into the unknown.'},description:{kk:'Әр бұрылыста жаңа сынақ, әр жеңісте жаңа мүмкіндік бар.',ru:'За каждым поворотом — испытание, а за каждой победой — новая возможность.',en:'Every turn brings a challenge; every victory opens a new possibility.'}},
  {gameId:'the-witcher-3',kicker:{kk:'ҰМЫТЫЛМАС САПАР',ru:'ПУТЕШЕСТВИЕ, КОТОРОЕ ЗАПОМНИТСЯ',en:'A JOURNEY TO REMEMBER'},title:{kk:'Оқиғаңды өзің таңда.',ru:'Выбери свою историю.',en:'Choose your story.'},description:{kk:'Қиын шешімдер мен ерекше кейіпкерлерге толы фэнтези әлеміне ен.',ru:'Погрузись в фэнтези-мир сложных решений и ярких персонажей.',en:'Enter a fantasy world full of difficult choices and unforgettable characters.'}}
];

const GENRE_ORDER = ['action','combat','horror','adventure','rpg','multiplayer','sandbox','simulation','strategy'];
let currentLanguage = 'kk';
let activeGenre = 'all';
let heroIndex = 0;
let heroTimer = null;
let activeDetailGame = null;

function t(key) {
  const dict = I18N[currentLanguage] || I18N.kk;
  return dict[key] ?? I18N.kk[key] ?? key;
}
function getGame(id) { return GAME_DATA.find((game) => game.id === id) || GAME_DATA[0]; }
function gameTitle(game) { return game.title; }
function gameDescription(game) { return game.description[currentLanguage] || game.description.en; }
function genreLabel(genre) { return (I18N[currentLanguage].genres || I18N.kk.genres)[genre] || genre; }
function getFavorites() {
  try { const value = JSON.parse(localStorage.getItem('playoraFavoriteIds') || '[]'); return Array.isArray(value) ? value : []; }
  catch (_) { return []; }
}
function setFavorites(favorites) {
  try { localStorage.setItem('playoraFavoriteIds', JSON.stringify(favorites)); return true; }
  catch (_) { return false; }
}
function formatPrice(game) {
  if (game.price === 0) return t('freePrice');
  return new Intl.NumberFormat(currentLanguage === 'en' ? 'en-US' : currentLanguage === 'ru' ? 'ru-RU' : 'kk-KZ').format(game.price) + ' ₸';
}
function steamImage(game, type = 'header.jpg') {
  if (!game.steamId) return '';
  return `https://cdn.akamai.steamstatic.com/steam/apps/${game.steamId}/${type}`;
}
function applyBackground(element, game, imageType = 'header.jpg') {
  if (!element) return;
  element.className = `${element.className.replace(/\btheme-[\w-]+\b/g, '').trim()} theme-${game.theme}`.trim();
  const image = steamImage(game, imageType);
  if (image) element.style.backgroundImage = `linear-gradient(180deg, rgba(6,8,12,.03) 0%, rgba(6,8,12,.18) 40%, rgba(6,8,12,.88) 100%), url("${image}")`;
  else element.style.backgroundImage = '';
  element.dataset.gameId = game.id;
}
function applyLanguage(language) {
  currentLanguage = I18N[language] ? language : 'kk';
  try { localStorage.setItem('playoraLanguage', currentLanguage); } catch (_) {}
  document.documentElement.lang = currentLanguage === 'kk' ? 'kk' : currentLanguage;
  if (document.querySelector('#loginForm')) document.title = `${t('loginTitle')} — Playora`;
  if (document.querySelector('#registerForm')) document.title = `${t('registerTitle')} — Playora`;
  document.querySelectorAll('#languageSelect').forEach((select) => { select.value = currentLanguage; });
  document.querySelectorAll('[data-i18n]').forEach((element) => {
    const key = element.dataset.i18n;
    if (I18N[currentLanguage][key] !== undefined) element.innerHTML = I18N[currentLanguage][key];
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((element) => {
    const value = I18N[currentLanguage][element.dataset.i18nPlaceholder];
    if (value !== undefined) element.setAttribute('placeholder', value);
  });
  document.querySelectorAll('[data-i18n-title]').forEach((element) => {
    const value = I18N[currentLanguage][element.dataset.i18nTitle];
    if (value !== undefined) element.setAttribute('title', value);
  });
  renderEverything();
}

function renderHero() {
  const stage = document.querySelector('#heroStage');
  if (!stage) return;
  const slide = HERO_SLIDES[heroIndex];
  const game = getGame(slide.gameId);
  const artwork = document.querySelector('#heroArtwork');
  applyBackground(artwork, game, 'library_hero.jpg');
  document.querySelector('#heroKicker').textContent = slide.kicker[currentLanguage];
  document.querySelector('#heroTitle').textContent = slide.title[currentLanguage];
  document.querySelector('#heroDescription').textContent = slide.description[currentLanguage];
  document.querySelector('#heroMeta').innerHTML = `<span class="hero-rating"><b>★</b> ${game.rating.toFixed(1)}</span><span>${genreLabel(game.genres[0])}</span><span>${game.year}</span>`;
  document.querySelector('#heroDetails').href = `game.html?id=${encodeURIComponent(game.id)}`;
  const favorite = document.querySelector('#heroFavorite');
  if (favorite) favorite.dataset.favorite = game.id;
  const counter = document.querySelector('#heroCounter');
  if (counter) counter.textContent = `${String(heroIndex + 1).padStart(2,'0')} / ${String(HERO_SLIDES.length).padStart(2,'0')}`;
  const dots = document.querySelector('#heroDots');
  if (dots) dots.innerHTML = HERO_SLIDES.map((item, index) => `<button type="button" class="slider-dot ${index === heroIndex ? 'active' : ''}" data-hero-index="${index}" aria-label="Slide ${index + 1}" aria-pressed="${index === heroIndex}"></button>`).join('');
  updateFavoriteButtons();
}

function renderGameCard(game, variant = 'catalog') {
  const genres = game.genres.slice(0, 2).map(genreLabel).join(' · ');
  const coverUrl = steamImage(game, 'header.jpg');
  const style = coverUrl ? `style="background-image:linear-gradient(180deg,rgba(4,6,10,.05),rgba(4,6,10,.78)),url('${coverUrl}')"` : '';
  const priceLabel = formatPrice(game);
  const rating = `${game.rating.toFixed(1)}`;
  const artLabel = `${game.title} cover art`;
  const yearBadge = `<span class="card-year">${game.year}</span>`;
  const poster = `<a class="game-tile-art theme-${game.theme}" ${style} href="game.html?id=${encodeURIComponent(game.id)}" aria-label="${artLabel}"><span class="poster-code">${game.code}</span><span class="poster-bottom-line">${game.title}</span>${yearBadge}</a>`;
  const details = `<div class="game-tile-info"><div class="game-tile-title-row"><div><p class="game-tile-genres">${genres}</p><a href="game.html?id=${encodeURIComponent(game.id)}" class="game-tile-title">${game.title}</a></div><span class="game-rating"><b>★</b>${rating}</span></div><div class="game-tile-bottom"><span class="game-price ${game.price === 0 ? 'is-free' : ''}">${priceLabel}</span><button class="favorite-button" type="button" data-favorite="${game.id}" aria-label="Add ${game.title} to favorites" aria-pressed="false">♡</button></div></div>`;
  return `<article class="game-tile ${variant === 'featured' ? 'game-tile-featured' : ''} ${variant === 'horizontal' ? 'game-tile-horizontal' : ''}">${poster}${details}</article>`;
}

function renderCuratedGrids() {
  const fill = (selector, ids, variant) => {
    const element = document.querySelector(selector);
    if (element) element.innerHTML = ids.map((id) => renderGameCard(getGame(id), variant)).join('');
  };
  fill('#popularGrid', ['genshin-impact','minecraft','roblox','elden-ring','final-fantasy-xiv'], 'featured');
  fill('#topWeekGrid', ['cyberpunk-2077','the-witcher-3','valorant','phasmophobia'], 'horizontal');
  fill('#freeGrid', ['genshin-impact','roblox','valorant','dota-2','apex-legends'], 'horizontal');
  fill('#paidGrid', ['elden-ring','cyberpunk-2077','minecraft','the-witcher-3','phasmophobia'], 'horizontal');
}

function renderCatalog() {
  const grid = document.querySelector('#gamesGrid');
  if (!grid) return;
  const search = (document.querySelector('#gameSearch')?.value || '').trim().toLocaleLowerCase(currentLanguage);
  const sortMode = document.querySelector('#sortGames')?.value || 'rating';
  let visible = GAME_DATA.filter((game) => {
    const searchable = [game.title, game.publisher, ...game.genres.map(genreLabel), ...Object.values(game.description)].join(' ').toLocaleLowerCase(currentLanguage);
    return searchable.includes(search) && (activeGenre === 'all' || game.genres.includes(activeGenre));
  });
  visible.sort((a,b) => {
    if (sortMode === 'az') return a.title.localeCompare(b.title);
    if (sortMode === 'newest') return b.year - a.year;
    if (sortMode === 'oldest') return a.year - b.year;
    if (sortMode === 'price') return a.price - b.price;
    return b.rating - a.rating;
  });
  grid.innerHTML = visible.map((game) => renderGameCard(game, 'catalog')).join('');
  const count = document.querySelector('#resultsCount');
  if (count) count.textContent = `${visible.length} ${t('countGames')}`;
  const empty = document.querySelector('#emptyState');
  if (empty) empty.classList.toggle('hidden', visible.length !== 0);
  document.querySelectorAll('[data-filter]').forEach((button) => {
    if (!button.classList.contains('filter-chip') && !button.classList.contains('genre-tile')) return;
    const chosen = button.dataset.filter === activeGenre;
    if (button.classList.contains('filter-chip')) {
      button.classList.toggle('active', chosen);
      button.setAttribute('aria-pressed', String(chosen));
    } else {
      button.classList.toggle('selected', chosen);
      button.setAttribute('aria-pressed', String(chosen));
    }
  });
  updateFavoriteButtons();
}

function renderGameDetail() {
  const titleElement = document.querySelector('#detailTitle');
  if (!titleElement) return;
  const params = new URLSearchParams(window.location.search);
  activeDetailGame = getGame(params.get('id') || 'elden-ring');
  const game = activeDetailGame;
  document.title = `${game.title} — Playora`;
  titleElement.textContent = game.title;
  document.querySelector('#detailPublisher').textContent = game.publisher;
  document.querySelector('#detailRating').textContent = game.rating.toFixed(1);
  document.querySelector('#detailVoteCount').textContent = `${game.votes} ${currentLanguage === 'en' ? 'demo ratings' : currentLanguage === 'ru' ? 'демо-оценок' : 'демо бағалау'}`;
  document.querySelector('#detailDescription').textContent = gameDescription(game);
  document.querySelector('#detailPrice').textContent = formatPrice(game);
  document.querySelector('#detailTags').innerHTML = game.genres.map((genre) => `<span>${genreLabel(genre)}</span>`).concat([`<span>${game.year}</span>`]).join('');
  const detailArt = document.querySelector('#detailArtwork');
  applyBackground(detailArt, game, 'library_hero.jpg');
  const fallback = document.querySelector('#detailArtFallback');
  if (fallback) fallback.textContent = game.code;
  const favorite = document.querySelector('#detailFavorite');
  if (favorite) favorite.dataset.favorite = game.id;
  const factData = [
    ['genre', game.genres.map(genreLabel).join(', ')],
    ['year', String(game.year)],
    ['mode', game.mode === 'single' ? t('modeSingle') : game.mode === 'online' ? t('modeOnline') : t('modeMixed')],
    ['platforms', game.platforms.join(', ')],
    ['publisher', game.publisher],
    ['languageCount', String(game.languages.length)]
  ];
  document.querySelector('#detailFacts').innerHTML = factData.map(([key,value]) => {
    const label = key === 'languageCount' ? t('factLanguageCount') : t(`fact${key.charAt(0).toUpperCase()}${key.slice(1)}`);
    return `<div class="detail-fact"><span>${label}</span><strong>${value}</strong></div>`;
  }).join('');
  const languageNames = I18N[currentLanguage].langs;
  document.querySelector('#detailLanguages').innerHTML = game.languages.map((language) => `<span class="language-pill"><i></i>${languageNames[language] || language}</span>`).join('');
  renderGallery(game);
  updateFavoriteButtons();
}

function renderGallery(game) {
  const gallery = document.querySelector('#detailGallery');
  if (!gallery) return;
  const galleryTypes = ['library_hero.jpg','header.jpg','capsule_616x353.jpg'];
  gallery.innerHTML = galleryTypes.map((type,index) => {
    const image = steamImage(game,type);
    const style = image ? `style="background-image:linear-gradient(180deg,rgba(4,6,10,.02),rgba(4,6,10,.65)),url('${image}')"` : '';
    return `<button type="button" class="gallery-shot theme-${game.theme}" ${style} data-gallery-index="${index}" aria-label="${t('galleryImage')} ${index + 1}: ${game.title}"><span class="gallery-shot-index">0${index + 1}</span><span class="gallery-shot-title">${game.title}</span><span class="gallery-shot-open">↗</span></button>`;
  }).join('');
}

function renderEverything() {
  renderHero();
  renderCuratedGrids();
  renderCatalog();
  renderGameDetail();
  updateFavoriteButtons();
}

function showToast(message) {
  const toast = document.querySelector('#toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timeoutId);
  showToast.timeoutId = window.setTimeout(() => toast.classList.remove('show'), 2300);
}

function updateFavoriteButtons() {
  const favorites = getFavorites();
  document.querySelectorAll('[data-favorite]').forEach((button) => {
    const id = button.dataset.favorite;
    const saved = favorites.includes(id);
    button.classList.toggle('is-favorite', saved);
    button.setAttribute('aria-pressed', String(saved));
    const game = getGame(id);
    if (button.classList.contains('favorite-button')) {
      button.textContent = saved ? '♥' : '♡';
      button.setAttribute('aria-label', `${game.title}: ${saved ? (currentLanguage === 'ru' ? 'удалить из избранного' : currentLanguage === 'en' ? 'remove from favorites' : 'таңдаулылардан алып тастау') : (currentLanguage === 'ru' ? 'добавить в избранное' : currentLanguage === 'en' ? 'add to favorites' : 'таңдаулыларға қосу')}`);
    } else {
      const text = button.querySelector('[data-i18n]');
      if (text) text.textContent = saved ? t('heroSaved') : t('heroSave');
      const icon = button.querySelector('span[aria-hidden="true"]');
      if (icon) icon.textContent = saved ? '♥' : '♡';
    }
  });
}

function setupCatalogInteractions() {
  document.querySelector('#gameSearch')?.addEventListener('input', renderCatalog);
  document.querySelector('#sortGames')?.addEventListener('change', renderCatalog);
  document.querySelectorAll('[data-filter]').forEach((button) => {
    button.addEventListener('click', () => {
      activeGenre = button.dataset.filter || 'all';
      renderCatalog();
      if (button.classList.contains('genre-tile')) document.querySelector('#catalog')?.scrollIntoView({ behavior:'smooth', block:'start' });
    });
  });
  document.querySelector('#resetFilters')?.addEventListener('click', () => {
    activeGenre = 'all';
    const search = document.querySelector('#gameSearch');
    if (search) search.value = '';
    renderCatalog();
  });
  document.querySelector('#heroPrev')?.addEventListener('click', () => changeHero(-1));
  document.querySelector('#heroNext')?.addEventListener('click', () => changeHero(1));
  document.querySelector('#heroDots')?.addEventListener('click', (event) => {
    const button = event.target.closest('[data-hero-index]');
    if (!button) return;
    heroIndex = Number(button.dataset.heroIndex);
    renderHero(); restartHeroTimer();
  });
  document.querySelector('#heroStage')?.addEventListener('mouseenter', () => window.clearInterval(heroTimer));
  document.querySelector('#heroStage')?.addEventListener('mouseleave', restartHeroTimer);
}
function changeHero(step) {
  heroIndex = (heroIndex + step + HERO_SLIDES.length) % HERO_SLIDES.length;
  renderHero(); restartHeroTimer();
}
function restartHeroTimer() {
  window.clearInterval(heroTimer);
  if (!document.querySelector('#heroStage')) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  heroTimer = window.setInterval(() => { heroIndex = (heroIndex + 1) % HERO_SLIDES.length; renderHero(); }, 8500);
}

function setupFavorites() {
  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-favorite]');
    if (!button) return;
    event.preventDefault();
    const id = button.dataset.favorite;
    const favorites = getFavorites();
    const index = favorites.indexOf(id);
    const game = getGame(id);
    if (index >= 0) {
      favorites.splice(index,1);
      showToast(`«${game.title}» ${t('toastRemoved')}`);
    } else {
      favorites.push(id);
      showToast(`«${game.title}» ${t('toastAdded')}`);
    }
    if (!setFavorites(favorites)) showToast(t('toastStorage'));
    updateFavoriteButtons();
  });
}

function setupLanguage() {
  let preferred = 'kk';
  try { preferred = localStorage.getItem('playoraLanguage') || 'kk'; } catch (_) {}
  const select = document.querySelector('#languageSelect');
  if (select) select.addEventListener('change', () => applyLanguage(select.value));
  applyLanguage(preferred);
}

function setupGalleryLightbox() {
  const lightbox = document.querySelector('#imageLightbox');
  const image = document.querySelector('#lightboxImage');
  const caption = document.querySelector('#lightboxCaption');
  const close = () => lightbox?.classList.add('hidden');
  document.querySelector('#detailGallery')?.addEventListener('click', (event) => {
    const shot = event.target.closest('[data-gallery-index]');
    if (!shot || !lightbox || !image) return;
    image.className = `lightbox-image theme-${activeDetailGame?.theme || 'cyber'}`;
    image.style.backgroundImage = shot.style.backgroundImage || '';
    caption.textContent = `${activeDetailGame?.title || 'Playora'} · ${t('galleryImage')} ${Number(shot.dataset.galleryIndex) + 1}`;
    lightbox.classList.remove('hidden');
  });
  close && document.querySelector('#lightboxClose')?.addEventListener('click', close);
  lightbox?.addEventListener('click', (event) => { if (event.target === lightbox) close(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') close(); });
}

// Login form: client-side validation only, as planned for week 9.
const loginForm = document.querySelector('#loginForm');
if (loginForm) {
  const passwordInput = document.querySelector('#loginPassword');
  const showPasswordLink = document.querySelector('#showPassword');
  const message = document.querySelector('#loginMessage');
  showPasswordLink?.addEventListener('click', (event) => {
    event.preventDefault();
    const isHidden = passwordInput.type === 'password';
    passwordInput.type = isHidden ? 'text' : 'password';
    showPasswordLink.textContent = isHidden ? t('loginHide') : t('loginShow');
  });
  loginForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!loginForm.reportValidity()) return;
    message.textContent = t('loginValid');
  });
}

// Registration form: required-field validation and password match only.
const registerForm = document.querySelector('#registerForm');
if (registerForm) {
  const password = document.querySelector('#registerPassword');
  const confirmPassword = document.querySelector('#confirmPassword');
  const message = document.querySelector('#registerMessage');
  registerForm.addEventListener('submit', (event) => {
    event.preventDefault();
    confirmPassword.setCustomValidity('');
    if (password.value !== confirmPassword.value) {
      confirmPassword.setCustomValidity(t('registerMismatch'));
      confirmPassword.reportValidity();
      message.textContent = t('registerMismatch');
      return;
    }
    if (!registerForm.reportValidity()) return;
    message.textContent = t('registerValid');
    registerForm.reset();
  });
  confirmPassword.addEventListener('input', () => confirmPassword.setCustomValidity(''));
}

// Small-screen navigation.
const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');
menuToggle?.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('mobile-open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.textContent = isOpen ? '×' : '☰';
});
mainNav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  mainNav.classList.remove('mobile-open');
  menuToggle?.setAttribute('aria-expanded','false');
  if (menuToggle) menuToggle.textContent = '☰';
}));

setupCatalogInteractions();
setupFavorites();
setupGalleryLightbox();
setupLanguage();
restartHeroTimer();
